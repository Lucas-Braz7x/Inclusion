﻿const enviar = (evento) => {
  evento.preventDefault();

  alert("Formulário enviado com sucesso!!");
}